# import itertools
# import sys
# import time

# class Spinner:
#     def __init__(self):
#         self.__seq = itertools.cycle(['-', '/', '|', '\\'])
#
#     def run(self):
#         while True:
#             time.sleep(0.4)
#             sys.stdout.write(next(self.__seq))  # write the next character
#             sys.stdout.flush()  # flush stdout buffer (actual character display)
#             sys.stdout.write('\b')  # erase the last written char


import sys
import time
import threading
import itertools


class Spinner:
    busy = False
    delay = 0.1

    @staticmethod
    def spinning_cursor():
        while True:
            for cursor in "|/-\\":
                yield cursor

    def __init__(self, delay=None):
        self.__seq = itertools.cycle(['-', '\\', '|', '/'])
        if delay and float(delay):
            self.delay = delay

    def msg(self, msg, field_size=None):
        self.inner_stop()
        sys.stdout.write("\x1b[2K\r")
        if field_size is None:
            sys.stdout.write(msg)
        else:
            formatter = "{: <%d}" % field_size
            sys.stdout.write(formatter.format(msg))
        sys.stdout.write(" ")
        self.start()

    def spinner_task(self):
        while self.busy:
            sys.stdout.write(next(self.__seq))
            sys.stdout.flush()
            time.sleep(self.delay)
            sys.stdout.write("\b")
            sys.stdout.flush()

    def start(self):
        self.busy = True
        threading.Thread(target=self.spinner_task).start()

    def inner_stop(self):
        self.busy = False
        time.sleep(self.delay)

    def stop(self):
        self.busy = False
        time.sleep(self.delay)
        self.flush()

    @staticmethod
    def flush():
        sys.stdout.write("\x1b[2K\r")


# class ProgressBase(threading.Thread):
#     """Base class - not to be instanciated."""
#
#     def __init__(self):
#         self.rlock = threading.RLock()
#         self.cv = threading.Condition()
#         threading.Thread.__init__(self)
#         self.setDaemon(1)
#
#     def __backStep(self):
#         if self.inplace: sys.stdout.write('\b \b')
#
#     def __call__(self):
#         self.start()
#
#     def start(self):
#         self.stopFlag = 0
#         threading.Thread.start(self)
#
#     def stop(self):
#         """To be called by the 'main' thread: Method will block
#         and wait for the thread to stop before returning control
#         to 'main'."""
#
#         self.stopFlag = 1
#
#         # Wake up 'Sleeping Beauty' ahead of time (if it needs to)...
#         self.cv.acquire()
#         self.cv.notify()
#         self.cv.release()
#
#         # Block and wait here untill thread fully exits its run method.
#         self.rlock.acquire()
#
#
#
# class Spinner(ProgressBase):
#     """Print 'animated' /|\ sequence to stdout in separate thread"""
#
#     def __init__(self, speed=0.1):
#         self.__seq = [chr(47), "|", chr(92)]
#         self.__speed = speed
#         self.inplace = 1
#         ProgressBase.__init__(self)
#
#     def run(self):
#         self.rlock.acquire()
#         self.cv.acquire()
#         sys.stdout.write(' ')
#         while 1:
#             for char in self.__seq:
#                 self.cv.wait(self.__speed)  # 'Sleeping Beauty' part
#                 if self.stopFlag:
#                     self._ProgressBase__backStep()
#                     try :
#                         return                          ### >>>
#                     finally :
#                         # release lock immediatley after returning
#                         self.rlock.release()
#                 if self.inplace: sys.stdout.write('\b')
#                 sys.stdout.write(char)

if __name__ == "__main__":

    spinner = Spinner()
    # spinner.start()
    # time.sleep(1)
    spinner.msg("My msg", 20)
    time.sleep(1)
    spinner.msg("2nd", 20)
    time.sleep(1)
    spinner.msg("This is the end !!!", 20)
    time.sleep(1)
    spinner.stop()


